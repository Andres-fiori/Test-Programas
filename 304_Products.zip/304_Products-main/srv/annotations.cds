using {ProductSRV as service} from './products';

annotate service.ProductSet with @odata.draft.enabled;

annotate service.ProductSet with {
    product @title : 'Product';
    productName @title : 'Product Name';
    description @title : 'Description';
    price @title : 'Price';
    currency @title : 'Currency';
};

annotate service.ProductSet with {
    currency @Common : { 
        Text : currency.name,
        TextArrangement : #TextOnly,
        ValueList : {
            $Type : 'Common.ValueListType',
            CollectionPath : 'VH_CurrencySet',
            Parameters : [
                {
                    $Type : 'Common.ValueListParameterInOut',
                    LocalDataProperty : currency_code,
                    ValueListProperty : 'code'
                }
            ]
        }
     }
};


annotate service.ProductSet with @(
    UI.SelectionFields  : [
        product,
        currency_code
    ],
    UI.HeaderInfo                : {
        $Type         : 'UI.HeaderInfoType',
        TypeName      : 'Product',
        TypeNamePlural: 'Products',
        Title         : {
            $Type: 'UI.DataField',
            Value: productName,
        },
        Description   : {
            $Type: 'UI.DataField',
            Value: product,
        },
    },
    UI.LineItem                  : [
        {
            $Type: 'UI.DataField',
            Value: product,
        },
        {
            $Type: 'UI.DataField',
            Value: productName,
        },
        {
            $Type: 'UI.DataField',
            Value: description,
        },
        {
            $Type: 'UI.DataField',
            Value: price,
        },
    ],
    UI.FieldGroup #GeneratedGroup: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Value: product,
            },
            {
                $Type: 'UI.DataField',
                Value: productName,
            },
            {
                $Type: 'UI.DataField',
                Value: description,
            },
            {
                $Type: 'UI.DataField',
                Value: price,
            }
        ],
    },
    UI.Facets                    : [{
        $Type : 'UI.ReferenceFacet',
        ID    : 'GeneralInformation',
        Label : 'General Information',
        Target: '@UI.FieldGroup#GeneratedGroup',
    }, ]
);
annotate service.VH_CurrencySet with {
    code @title:'Currencies' @Common:{
        Text : name,
        TextArrangement : #TextOnly
    };
};


