using {com.logaligroup as entities} from '../db/schema';

service ProductSRV {
    entity ProductSet as projection on entities.Products;
    entity VH_CurrencySet as projection on entities.VH_Currencies;
};