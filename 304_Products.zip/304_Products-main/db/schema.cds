namespace com.logaligroup;

using {
    cuid,
    sap.common.CodeList
} from '@sap/cds/common';

entity Products : cuid {
    product     : String(8)       @title: 'Product'       @mandatory  @assert.notNull;
    productName : String(120)     @title: 'Product Name'  @mandatory  @assert.notNull;
    description : String(1255)    @title: 'Description'   @UI.MultiLineText;
    price       : Decimal(10, 8)  @title: 'Price'         @Measures.Unit        : currency_code;
    currency    : Association to VH_Currencies            @Common.IsUnit  @title: 'Currency';
};

entity VH_Currencies : CodeList {
    key code : String enum {
            USD = 'USD';
            EUR = 'EUR';
            COP = 'COP';
        }
};